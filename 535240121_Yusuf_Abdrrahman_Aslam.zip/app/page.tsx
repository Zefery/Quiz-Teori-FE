export default function Home() {
  return (
    <div className="container py-5">
      <div className="card shadow-lg p-4 bg-light">
        <h1 className="display-5 text-primary mb-3">
          e-makanan: Next.js Mini Web App
        </h1>
        <p className="lead border-bottom pb-2">
          Aplikasi Pemesanan Makanan Sederhana
        </p>
        
        <p className="mb-1">
          <strong>Nama:</strong> Yusuf Abdurrahman Aslam
        </p>
        <p className="mb-1">
          <strong>NIM:</strong> 535240121
        </p>
        <p className="mb-0">
          <strong>Topik Project:</strong> Pemesanan Makanan "e-makanan"
        </p>
        
        <div className="mt-4">
          <a href="/menu" className="btn btn-success btn-lg">
            Mulai Kelola Menu 
          </a>
        </div>
      </div>
      
    </div>
  )
}