'use client';

import { useParams, useRouter } from 'next/navigation';
import { MenuItem } from '@/types/menu';
import { useEffect, useState } from 'react';

// Fungsi untuk mengambil data menu dari Local Storage
const getMenuFromLocalStorage = (): MenuItem[] => {
  if (typeof window !== 'undefined') {
    const savedMenu = localStorage.getItem('e-makanan-menu');
    return savedMenu ? JSON.parse(savedMenu) : [];
  }
  return [];
};

export default function MenuDetailPage() {
  // Mengambil parameter ID dari URL (Dynamic Routing)
  const params = useParams();
  const router = useRouter();
  const menuId = Array.isArray(params.id) ? params.id[0] : params.id;
  
  const [menuItem, setMenuItem] = useState<MenuItem | null>(null);

  // Cari item menu yang sesuai dengan ID saat komponen dimuat
  useEffect(() => {
    const menuList = getMenuFromLocalStorage();
    const item = menuList.find(m => m.id === menuId);
    if (item) {
      setMenuItem(item);
    } else {
      // Jika item tidak ditemukan, bisa redirect atau tampilkan pesan error
      setMenuItem(null);
    }
  }, [menuId]);

  // Handler tombol Back (Soal 3b)
  const handleBack = () => {
    router.back();
  };

  if (!menuItem) {
    return (
      <div className="container mt-5 text-center">
        <div className="alert alert-warning">
          Item menu dengan ID: **{menuId}** tidak ditemukan.
        </div>
        <button className="btn btn-secondary mt-3" onClick={handleBack}>
          ← Kembali ke Daftar Menu
        </button>
      </div>
    );
  }

  // Menampilkan konten item tersebut (Soal 3a, 5a)
  return (
    <div className="container my-5">
      <div className="card shadow-lg border-0">
        <div className="card-header bg-success text-white">
          <h1 className="card-title">{menuItem.name}</h1>
        </div>
        <div className="card-body">
          <dl className="row">
            <dt className="col-sm-3">Harga</dt>
            <dd className="col-sm-9">Rp{menuItem.price.toLocaleString('id-ID')}</dd>
            
            <dt className="col-sm-3">Deskripsi</dt>
            <dd className="col-sm-9">{menuItem.description}</dd>
            
            <dt className="col-sm-3">ID Item</dt>
            <dd className="col-sm-9 text-muted small">{menuItem.id}</dd>
          </dl>
          
          <hr/>
          {/* Tombol back ke halaman list (Soal 3b, 5a) */}
          <button className="btn btn-secondary" onClick={handleBack}>
            ← Kembali ke Daftar Menu
          </button>
        </div>
      </div>
    </div>
  );
}