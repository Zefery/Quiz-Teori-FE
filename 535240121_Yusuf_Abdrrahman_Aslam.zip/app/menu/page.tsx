import MenuManager from '../components/menumanager';

export default function MenuPage() {
  return (
    <div>
      {/* Komponen yang mengelola state dan list */}
      <MenuManager /> 
    </div>
  );
}